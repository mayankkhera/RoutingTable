import java.util.ArrayList;

public class Router{

	private ArrayList<RoutingTableEntry> routingTable;
	
	//default constructor
	public Router(){
		routingTable = new ArrayList<RoutingTableEntry>(100);
		for(int i=0; i<100; i++) {
			routingTable.add(null);
		}
	}
	
	//processes the packet by looking up in the table 
	public void processPacket(Packet pk){
		/*for(int i=0; i<routingTable.size(); i++){
			if(!routingTable.get(i).searchForPort(pk.getDestNetwork()).equals("")){
				pk.processFoundPacket(routingTable.get(i).searchForPort(pk.getDestNetwork()));
				return;
			}
		}*/
		if(routingTable.get(findIndex(pk))==null) {
			if(!pk.processNotFoundPacket(pk.getPacketData())) {
				System.out.println("inserting at index "+findIndex(pk)+" "+pk.getDestNetwork());
				RoutingTableEntry temp = new RoutingTableEntry();
				temp.addEntry(pk.getDestNetwork(), pk.getPacketData());
				routingTable.add(findIndex(pk), temp);
			}
		}else {
			if(!routingTable.get(pk.getDestNetwork().calcHash()).searchForPort(pk.getDestNetwork()).equals("")) {
				pk.processFoundPacket(routingTable.get(pk.getDestNetwork().calcHash()).searchForPort(pk.getDestNetwork()));
			}else {
				if(collisionResolution(pk)==-1) {
					System.out.println("Could not add "+pk.getDestNetwork()+" to the table - no empty spaces");
				}else {
					System.out.println("inserting at index "+collisionResolution(pk)+" "+pk.getDestNetwork()+" due to collision");
					RoutingTableEntry temp = new RoutingTableEntry();
					temp.addEntry(pk.getDestNetwork(), pk.getPacketData());
					routingTable.add(collisionResolution(pk), temp);
				}
			}
		}

		/*if(!pk.processNotFoundPacket(pk.getPacketData())){
			RoutingTableEntry temp = new RoutingTableEntry();
			temp.addEntry(pk.getDestNetwork(), pk.getPacketData());
			routingTable.add(findIndex(pk.getDestNetwork()),temp);
		}*/
	}

	//displays the sorted table when called
	public void displayTable(){

		System.out.println();
		System.out.println("Routing table is as follow: ");
		System.out.println();

		for(int i=0; i<routingTable.size(); i++){
			System.out.println(routingTable.get(i));
		}
	}

	//private method to lookup the suitable spot for the entry
	/*private int insertion(IPAddress add){
		for(int i=0; i<routingTable.size(); i++) {
			if(routingTable.get(i).ipcpr(add))
				return i;
		}
		return routingTable.size();
	}*/

	private int findIndex(Packet pk) {
		return pk.getDestNetwork().calcHash();		
	}
	
	public int collisionResolution(Packet pk) {
		int index = findIndex(pk);
		while(index<100) {
			if(routingTable.get(index)!=null)
				return index;
			index++;
		}
		return -1;
	}
	

}